TODO: Special setup notes.

## how to run
* install nodemon
```shell
npm install nodemon -g 
```
* install dependencies
```
npm install
```
* run
```
npm start
```

