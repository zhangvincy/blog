
const connection = require('./connection');
const utils = require('../utils/date');

const EncryptRsa = require('encrypt-rsa').default;

const encryptRsa = new EncryptRsa();

exports.checkUser = async (nickname, password) => {
    let conn;
    var res = {};
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("select UserID, UserNickName, UserPassword, Avatar from users where UserNickName=?", [nickname]);
        if (db_res.length == 0) {
            res['code'] = 0;
        } else {
            res['code'] = 1;
            const user = db_res[0];
            const decryptedPassword = encryptRsa.decryptStringWithRsaPrivateKey({
                text: user.UserPassword,
                privateKey: process.env.PRIVATE_KEY,
            });

            if (password == decryptedPassword) {
                res['correct'] = 1;
                res['nickname'] = user.UserNickName;
                res['avatar'] = user.Avatar;
                res['userId'] = user.UserID;
            } else {
                res['correct'] = 0;
            }
        }

    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}


exports.checkNickName = async (nickName) => {
    let conn;
    var res = {};
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("select * from users where UserNickName = ?", [nickName]);
        if (db_res.length == 0) {
            res = {
                code: 0,
                msg: 'nickName not exits'
            }
        } else {
            res = {
                code: 1,
                msg: 'nickName exits'
            }
        }

    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}


exports.createUser = async (user) => {
    let conn;
    try {
        conn = await connection.pool.getConnection();
        await conn.query("insert into users(UserNickName, UserPassword, UserRealName, UserBirthDay, Description, Avatar, InsertTime) value (?, ?, ?, ?, ?, ?, ?)",
            [user.nickName, user.password, user.realName, user.birthday, user.description, user.avatar, new Date()]);
    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return {
        code: 1,
        msg: "create successful"
    }
}

exports.deleteUser = async (userId) => {
    let conn;
    try {
        conn = await connection.pool.getConnection();
        await conn.query("delete stars from stars left join users on stars.CreateUserID = users.UserID where users.UserID=?", [userId]);
        await conn.query("delete stars from stars left join articles on stars.ArticleID = articles.ArticleID where articles.CreateUserID=?", [userId]);
        await conn.query("delete subcomments, comments from articles, subcomments, comments where subcomments.PCommentID = comments.CommentID and comments.ArticleID = articles.ArticleID and articles.CreateUserID = ?", [userId]);
        await conn.query("delete subcomments, comments from users, subcomments, comments where subcomments.PCommentID = comments.CommentID and comments.CreateUserID = users.UserID and users.UserID = ?", [userId]);

        await conn.query("delete articles, comments from users, articles, comments where articles.ArticleID = comments.ArticleID and users.UserID = articles.CreateUserID and users.UserID = ?", [userId]);
        // await conn.query("delete articles from users, articles where articles.CreateUserID = users.UserID and users.UserID = ?", [userId]);

        await conn.query("delete articles from users, articles where articles.CreateUserID = users.UserID and users.UserID = ?", [userId]);
        await conn.query("delete users from users where users.UserID = ?", [userId]);
    } catch (err) {
        console.log(err);
    } finally {
        if (conn) conn.release();
    }
}

exports.queryAvatar = async (userId) => {
    let conn;
    let res;
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("select Avatar from users where UserID=?", [userId]);
        if (db_res.length > 0) {
            res = db_res[0].Avatar;
        }
    } catch (err) {
        console.log(err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}

exports.queryNickNameByUserId = async (userId) => {
    let conn;
    var res = "";
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("select UserNickName from users where UserID = ?", [userId]);
        if (db_res.length > 0) {
            res = db_res[0].UserNickName;
        }
    } catch (err) {
        console.log(err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}

exports.queryByUserId = async (userId) => {
    let conn;
    var res;
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("select * from users where UserID = ?", [userId]);
        if (db_res.length > 0) {
            res = db_res[0];
        }
    } catch (err) {
        console.log(err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}

exports.update = async (nickname, password, realName, description, birthday, userId) => {
    let conn;
    try {
        conn = await connection.pool.getConnection();
        await conn.query("update users set UserNickName = ?, UserPassword = ?, UserRealName = ?, UserBirthDay = ?, Description = ? where UserID = ?",
            [nickname, password, realName, birthday, description, userId]);
    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return {
        code: 1,
        msg: "create successful"
    }
}



// const connection = require('./connection');
// const utils = require('../utils/date');
//
//
// exports.checkUser = async(username, password) => {
//     let conn;
//     var res = {};
//     try {
//         conn = await connection.pool.getConnection();
//         const db_res = await conn.query("select UserName, UserPassword, Avatar from users where UserName=?", [username]);
//         if (db_res.length == 0) {
//             res['code'] = 0;
//         } else {
//             res['code'] = 1;
//             const user = db_res[0];
//             if (password == user.UserPassword) {
//                 res['correct'] = 1;
//                 res['username'] = user.UserName;
//                 res['avatar'] = user.Avatar;
//             } else {
//                 res['correct'] = 0;
//             }
//         }
//
//     } catch (err) {
//         console.log("errorL ", err);
//     } finally {
//         if (conn) conn.release();
//     }
//     return res;
// }
//
//
// exports.createUser = async (username, password, avatar) => {
//     let conn;
//     try {
//         conn = await connection.pool.getConnection();
//         await conn.query("insert into users value (?, ?, ?, ?)", [username, password, avatar, utils.getTime()]);
//     } catch(err) {
//         console.log("errorL ", err);
//     } finally {
//         if (conn) conn.release();
//     }
//     return {
//         code: 1,
//         msg: "create successful"
//     }
// }
//
// exports.deleteUser = async(username) => {
//     let conn;
//     try {
//         conn = await connection.pool.getConnection();
//         await conn.query("delete from users where UserName=?", [username]);
//     } catch(err) {
//         console.log(err);
//     } finally {
//         if (conn) conn.release();
//     }
// }
//
// exports.queryAvatar = async(username) => {
//     let conn;
//     let res;
//     try {
//         conn = await connection.pool.getConnection();
//         const db_res = await conn.query("select Avatar from users where UserName=?", [username]);
//         if (db_res.length > 0) {
//             res = db_res[0].Avatar;
//         }
//     } catch(err) {
//         console.log(err);
//     } finally {
//         if (conn) conn.release();
//     }
//     return res;
// }
