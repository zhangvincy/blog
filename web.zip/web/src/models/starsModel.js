const connection = require('./connection');


exports.createStar = async (username, articleId) => {
    let conn;
    var res = {};
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("insert into stars(UserName, ArticleID, InsertTime) value (?, ?, ?)", [username, articleId, new Date()]);
    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}

exports.queryStar = async(username, articleId) => {
    let conn;
    var res = {};
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("select * from stars where ArticleID=? and UserName=?", [articleId, username]);
        if (db_res.length > 0) {
            res = db_res[0];
        }
    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}

exports.queryStarByArticleId = async (articleId) => {
    let conn;
    var res = {};
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("select * from stars where ArticleID=?", [articleId]);
        res['stars'] = db_res;
    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}

exports.queryByUserName = async (username) => {
    let conn;
    var res = {};
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("select * from stars where UserName=?", [username]);
        res['stars'] = db_res;
    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}

exports.deleteStar = async (username, articleId) => {
    let conn;
    var res = {};
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("delete from stars where ArticleID=? and UserName=?", [articleId, username]);
    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}

exports.deleteAllWithArticlesId = async (articleId) => {
    let conn;
    var res = {};
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("delete from stars where ArticleID=?", [articleId]);
    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}
