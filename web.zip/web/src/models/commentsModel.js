const connection = require('./connection');


exports.createComment = async (username, articleId, comment) => {
    let conn;
    var res = {};
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("insert into comments(UserName, ArticleID, Comment, InsertTime) value (?, ?, ?, ?)", [username, articleId, comment, new Date()]);
    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}

exports.deleteComment = async (CommentId) => {
    let conn;
    var res = {};
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("delete from comments where CommentID = ? ", [CommentId]);
    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}

exports.updateComment = async (CommentId) => {

}

exports.queryByArticleId = async (articleId) => {
    let conn;
    var res = {};
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("select * from comments where ArticleID=?", [articleId]);
        if (db_res.length > 0) {
            res['comments'] = db_res;
        }
    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}
