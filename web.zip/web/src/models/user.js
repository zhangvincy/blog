exports.User = class User {
  constructor(nickName, password, realName, birthday, avatar, description) {
    this.nickName = nickName;
    this.password = password;
    this.realName = realName;
    this.birthday = birthday;
    this.avatar = avatar;
    this.description = description;
  }
}