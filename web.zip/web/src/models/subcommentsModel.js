const connection = require('./connection');

exports.createSubComment = async (pCommendId, userId, talkTo, subcomment) => {
    let conn;
    var res = {};
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("insert into subcomments(PCommentID, CreateUserID, TalkTo, Comment, InsertTime) value (?, ?, ?, ?, ?)", [pCommendId, userId, talkTo, subcomment, new Date()]);
    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}

exports.deleteSubComment = async (SubCommentId) => {
    let conn;
    var res = {};
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("delete from subcomments where SubCommentID = ?", [SubCommentId]);
    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}

exports.updateSubComment = async (SubCommentId) => {

}

exports.deleteAllWithPCommentID = async (pCommendId) => {
    let conn;
    var res = { };
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("delete from subcomments where PCommentID=?", [pCommendId]);
    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}

exports.queryByCommentId = async (commentId) => {
    let conn;
    var res = { sub_comments: [] };
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("select * from subcomments where PCommentID=?", [commentId]);
        if (db_res.length > 0) {
            res.sub_comments = db_res;
        }
    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}
