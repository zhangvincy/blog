const connection = require('./connection');


exports.createArticle = async(title, content, username) => {
    let conn;
    var res = {};
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("insert into articles(Title, Content, InsertTime, CreateUser) value (?, ?, ?, ?)",
            [title, content, new Date(), username]);

    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}

exports.queryAll = async() => {
    let conn;
    var res = {};
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query(" select * from articles");
        res['articles'] = db_res;
    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}

exports.deleteArticle = async(articleId) => {
    let conn;
    var res = {};
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("delete from articles where ArticleID = ?", [articleId]);

    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}

exports.updateArticle = async(articleId, content, title) => {
    let conn;
    var res = {};
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("update articles set Content = ?, Title = ?, InsertTime = ? where ArticleID = ?", [content, title, new Date(), articleId]);

    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}

exports.queryByUserName = async(username) => {
    let conn;
    var res = {};
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("select * from articles where CreateUser=?", [username]);
        if (db_res.length > 0) {
            res['articles'] = db_res;
        }

    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}

exports.queryById = async(articleId) => {
    let conn;
    var res = {};
    try {
        conn = await connection.pool.getConnection();
        const db_res = await conn.query("select * from articles where ArticleID=?", [articleId]);
        if (db_res.length > 0) {
            res = db_res[0];
        }

    } catch (err) {
        console.log("errorL ", err);
    } finally {
        if (conn) conn.release();
    }
    return res;
}

