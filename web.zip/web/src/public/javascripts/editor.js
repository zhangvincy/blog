const { createEditor, createToolbar, i18nChangeLanguage } = window.wangEditor

var html_content;

const editorConfig = {
    placeholder: 'Type here...',
    onChange(editor) {
        const html = editor.getHtml()
        html_content = editor.getHtml();
    },
    MENU_CONF: {}
}

editorConfig.MENU_CONF['uploadImage'] = {
    server: 'http://localhost:3020/api/fileuploads',
    fieldName: 'file'
}

const editor = createEditor({
    selector: '#editor-container',
    html: '<p><br></p>',
    config: editorConfig,
    mode: 'default', // or 'simple'
})

i18nChangeLanguage('en')
// editor.i18next = window.i18next

const toolbarConfig = {}

const toolbar = createToolbar({
    editor,
    selector: '#toolbar-container',
    config: toolbarConfig,
    mode: 'default', // or 'simple'
})


const save_blog = async () => {
    const title = document.getElementById('title').value;
    if (title.length == 0) {
        alert("please input blog title");
    } else {
        const data = await authRequest('http://localhost:3020/api/articles/',
            'POST',
            JSON.stringify({ "username": username, "title": title, "content": html_content }));
        if (data.code == 1 ){
            alert(data.msg);
            window.location.href = `http://localhost:3020/index`;
        }

    }


}