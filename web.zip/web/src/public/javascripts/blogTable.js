

const detail = (r) => {
    const tr = r.parentNode.parentNode;
    const id = tr.childNodes[1].innerText;
    window.location.href = `http://localhost:3020/bloginfo/${id}`;
}


const star = async (r) => {
    const tr = r.parentNode.parentNode;
    const id = tr.childNodes[1].innerText;
    const nickname = localStorage.getItem('nickname');
    const token = localStorage.getItem('token');
    const starExits = await authRequest("http://localhost:3020/api/stars/query",
        'POST',
        JSON.stringify({ articleId: id }));
    if (starExits.code == 0) {
        await authRequest("http://localhost:3020/api/stars",
            'POST',
            JSON.stringify({ articleId: id }));
        console.log(`starIcon${id}`);
        document.getElementById(`starIcon${id}`).style.color = 'chartreuse';
        document.getElementById(`starValue${id}`).innerText = parseInt(document.getElementById(`starValue${id}`).innerText) + 1;
    } else {
        await authRequest("http://localhost:3020/api/stars/cancel",
            'POST',
            JSON.stringify({ articleId: id }));
        document.getElementById(`starIcon${id}`).style.color = 'white';
        document.getElementById(`starValue${id}`).innerText = parseInt(document.getElementById(`starValue${id}`).innerText) - 1;
    }
    window.location.href = `http://localhost:3020/${userId}/stararticles/`
}

const edit = (r) => {
    window.location.href = `http://localhost:3020/edit/${r.id}/`;
}

const blog_delete = async (r) => {
    const articleId = r.id.split('-')[0];
    const url = `http://localhost:3020/api/articles/${articleId}`;
    const data = await authRequest(url, "DELETE", JSON.stringify({}));
    if (data.code == 1) {
        alert(data.msg);
        window.location.href = window.location.href;
    }
}


( () => {

    var table = document.querySelector("#myTable"),
        ths = table.querySelectorAll("thead th"),
        trs = table.querySelectorAll("tbody tr");
    console.log(table);
    console.log(ths);
    console.log(trs);

    const makeArray = (nodelist) => {
        var arr = [];

        for (var i = 0; i < nodelist.length; i++) {
            arr.push(nodelist[i]);
        }

        return arr;
    }

    const clearClassName = (nodelist) => {
        for (var i = 0; i < nodelist.length; i++) {
            nodelist[i].className = "";
        }
    }

    const sortBy = (e) => {
        var target = e.target,
            thsArr = makeArray(ths),
            trsArr = makeArray(trs),
            index = thsArr.indexOf(target),
            df = document.createDocumentFragment(),
            order = (target.className === "" || target.className === "desc") ? "asc" : "desc";

        console.log(target);

        clearClassName(ths);

        trsArr.sort(function (a, b) {
            const timeRe = /\d{4}-\d{2}-\d{2} \d{1,2}:\d{1,2}:\d{1,2}/g

            var tdA = a.children[index].textContent,
                tdB = b.children[index].textContent;

            if (timeRe.test(tdA)) {
                tdA = new Date(tdA).getTime();
                tdB = new Date(tdB).getTime();
            }
            if (tdA < tdB) {
                return order === "asc" ? -1 : 1;
            } else if (tdA > tdB) {
                return order === "asc" ? 1 : -1;
            } else {
                return 0;
            }
        });

        trsArr.forEach(function (tr) {
            df.appendChild(tr);
        });

        target.className = order;

        table.querySelector("tbody").appendChild(df);
    }

    ths[1].onclick = sortBy;
    ths[2].onclick = sortBy;
    ths[3].onclick = sortBy;
    ths[5].onclick = sortBy;

})();



// const detail = (r) => {
//     const tr = r.parentNode.parentNode;
//     const id = tr.childNodes[1].innerText;
//     window.location.href = `http://localhost:3020/bloginfo/${id}`;
// }
//
//
// const star = async (r) => {
//     const tr = r.parentNode.parentNode;
//     const id = tr.childNodes[1].innerText;
//     const username = localStorage.getItem('username');
//     const token = localStorage.getItem('token');
//     const starExits = await authRequest("http://localhost:3020/api/stars/query",
//         'POST',
//         JSON.stringify({articleId: id}));
//     if (starExits.code == 0) {
//         await authRequest("http://localhost:3020/api/stars",
//             'POST',
//             JSON.stringify({articleId: id}));
//         console.log(`starIcon${id}`);
//         document.getElementById(`starIcon${id}`).style.color = 'chartreuse';
//         document.getElementById(`starValue${id}`).innerText = parseInt(document.getElementById(`starValue${id}`).innerText) + 1;
//     } else {
//         await authRequest("http://localhost:3020/api/stars/cancel",
//             'POST',
//             JSON.stringify({articleId: id}));
//         document.getElementById(`starIcon${id}`).style.color = 'white';
//         document.getElementById(`starValue${id}`).innerText = parseInt(document.getElementById(`starValue${id}`).innerText) - 1;
//     }
//     console.log(starExits);
// }
//
// const edit = (r) => {
//     window.location.href = `http://localhost:3020/edit/${r.id}/`;
// }
//
// const _delete = async (r) => {
//     const articleId = r.id.split('-')[0];
//     const url = `http://localhost:3020/api/articles/${articleId}`;
//     const data = await authRequest(url, "DELETE", JSON.stringify({}));
//     if(data.code == 1) {
//         alert(data.msg);
//         window.location.href = window.location.href;
//     }
// }