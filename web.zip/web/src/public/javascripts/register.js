
const check_user = () => {
    const username = document.getElementById("username").value;
    fetch('http://localhost:3020/api/users/checknickname', {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ "nickname": username})
    }).then((response) => response.json())
        .then((data) => {
            if (data.code == 0) {
                document.getElementById('nicknamerepeat').style.display = "none";
            }
            if (data.code == 1) {
                document.getElementById('nicknamerepeat').style.display = "flex";
            }

        }).catch(err => {
        console.error("error");
    });
}

const register = (port) => {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const passwordconfim = document.getElementById("passwordconfim").value;
    const realName = document.getElementById('realName').value;
    const description = document.getElementById('description').value;
    const birthday = document.getElementById('birthday').value;

    console.log(username, password, passwordconfim, realName, description, birthday);


    if (username.length == 0 || password.length == 0 || passwordconfim.length == 0 ||
        realName.length == 0 || description.length == 0 || birthday.length == 0) {
        alert("please input correct user information");
        return;
    }

    if (password != passwordconfim) {
        alert("password inconsistencies");
        return;
    }

    if (password.length < 6) {
        alert("password length is too short");
        return;
    }

    if (document.getElementById('nicknamerepeat').style.display == 'none') {
        var overlay = document.getElementById("overlay");
        overlay.style.display = "block";
    }

}


const avatar_action = () => {

}

const avatar_cancel = () => {
    var overlay = document.getElementById("overlay");
    overlay.style.display = "none";
}

const avatar_select = (port) => {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    var avatars = document.getElementsByName('avatar');

    const realName = document.getElementById('realName').value;
    const description = document.getElementById('description').value;
    const birthday = document.getElementById('birthday').value;

    for (let avatar in avatars) {
        if (avatars[avatar].checked) {
            console.log("avatar", avatars[avatar].id);
            fetch(`http://localhost:${port}/api/users/`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    "nickname": username,
                    "password": password,
                    "realname": realName,
                    "description": description,
                    "birthday": birthday,
                    "avatar": avatars[avatar].id
                })
            }).then((response) => response.json())
                .then((data) => {
                    if (data.code == 1) {
                        alert("User Registration Successful");
                        window.location.href = `http://localhost:${port}/login`;
                    }

                }).catch(err => {
                console.error("error");
            });

        }
    }
}





// const register = (port) => {
//     var username = document.getElementById("username").value;
//     var password = document.getElementById("password").value;
//     var passwordconfim = document.getElementById("passwordconfim").value;
//
//     var safety = true;
//     if (username.length == 0 || password.length == 0 || passwordconfim.length == 0) {
//         safety = false;
//         alert("please input correct user information");
//         return;
//     }
//
//     if (password != passwordconfim) {
//         safety = false;
//         alert("password inconsistencies");
//         return;
//     }
//
//     if (password.length < 6) {
//         safety = false;
//         alert("password length is too short");
//         return;
//     }
//
//     fetch(`http://localhost:${port}/api/users/checkuser`, {
//         method: "POST",
//         headers: {
//             "Content-Type": "application/json"
//         },
//         body: JSON.stringify({ "username": username, "password": password })
//     }).then((response) => response.json())
//         .then((data) => {
//             if (data.code == 0) {
//                 var overlay = document.getElementById("overlay");
//                 overlay.style.display = "block";
//             }
//             if (data.code == 1) {
//                 alert("user already exists, please recreate");
//             }
//
//         }).catch(err => {
//         console.error("error");
//     });
//
//     if (safety) {
//
//
//     }
// }
//
//
// const avatar_action = () => {
//
// }
//
// const avatar_cancel = () => {
//     var overlay = document.getElementById("overlay");
//     overlay.style.display = "none";
// }
//
// const avatar_select = (port) => {
//     var username = document.getElementById("username").value;
//     var password = document.getElementById("password").value;
//     var avatars = document.getElementsByName('avatar');
//     for (avatar in avatars) {
//         if (avatars[avatar].checked) {
//             console.log("avatar", avatars[avatar].id);
//             fetch(`http://localhost:${port}/api/users/`, {
//                 method: "POST",
//                 headers: {
//                     "Content-Type": "application/json"
//                 },
//                 body: JSON.stringify({
//                     "username": username,
//                     "password": password,
//                     "avatar": avatars[avatar].id
//                 })
//             }).then((response) => response.json())
//                 .then((data) => {
//                     if (data.code == 1) {
//                         alert("User Registration Successful");
//                         window.location.href = `http://localhost:${port}/login`;
//                     }
//
//                 }).catch(err => {
//                 console.error("error");
//             });
//
//         }
//     }
// }