const ids = window.location.href.split('/').slice(-2);
const id = (ids[1] == "") ? ids[0] : ids[1];


const url = `http://localhost:3020/api/articles/${id}`;
fetch(url)
    .then(data => {
        return data.json();
    })
    .then(data => {
        editor.setHtml(data.data.Content);

    })

const save_edit = async () => {
    const title = document.getElementById('title').value;
    const data = await authRequest(url, 'POST', JSON.stringify({content: editor.getHtml(), title: title}))
    if (data.code == 1) {
        alert(data.msg);
        window.location.href = "http://localhost:3020/qq/managearticle";
    }
}