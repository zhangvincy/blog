const modify = async () => {
  var nickname = document.getElementById("username").value;
  var password = document.getElementById("password").value;

  const realName = document.getElementById('realName').value;
  const description = document.getElementById('description').value;
  const birthday = document.getElementById('birthday').value;

  const resp = await authRequest('http://localhost:3020/api/users/update', 'POST', JSON.stringify({
    nickname: nickname,
    password: password,
    realName: realName,
    description: description, 
    birthday: birthday
  }));
  if (resp.code == 1) {
    alert(resp.msg);
    localStorage.setItem('token', resp.token);
    localStorage.setItem('nickname', resp.nickname);
    window.location.href = "http://localhost:3020/";
  }

}


const delete_account = async () => {
  const resp = await authRequest('http://localhost:3020/api/users/delete', "POST", JSON.stringify({

  }));
  if (resp.code == 1) {
    alert(resp.msg);
    localStorage.removeItem('token');
    localStorage.removeItem('nickname');
    localStorage.removeItem('t-userId');
    localStorage.removeItem('avatar');
    localStorage.removeItem('userId');
    localStorage.removeItem('t-p-commentiD');
    localStorage.removeItem('t-sub-userId');
    localStorage.removeItem('t-commentId');
    localStorage.removeItem('t-sub-commentId');
    window.location.href = "http://localhost:3020/"
  } 
}