const articleId = window.location.href.split('/').slice(-1);
const author = document.getElementById('author').innerHTML;
const authorId = document.getElementById('authorId').innerHTML;

const dcommentStr = document.getElementById('dcomments').innerHTML;

localStorage.removeItem('t-used');

const save_comment = async () => {
    const comment = document.getElementById('comment').value;
    if (comment.length == 0) {
        alert("please input comment");
    } else{
        const data = await authRequest('http://localhost:3020/api/comments',
            "POST",
            JSON.stringify({
                ArticleID: articleId,
                Comment: comment
            }));
        if (data.code == 1) {
            alert("create comment successful");
            window.location.href = window.location.href;
        }

    }
}

const reply = async (r) => {
    const cid_un = r.id.split('-');
    const commentId = cid_un[0];
    const usedBlock = localStorage.getItem('t-used');

    console.log("=-----------------------");
    if (usedBlock) {
        const e = document.getElementById(usedBlock);
        if (e) {
            e.style.display = 'none';
        }
    }

    localStorage.setItem('t-commentId', cid_un[0]);
    localStorage.setItem('t-userId', cid_un[1]);
    localStorage.setItem('t-used', commentId);

    document.getElementById(commentId).style.display = 'block';
    // const data = authRequest('http://');
}

const save_sub_comment = async() => {
    const t_commentId = localStorage.getItem('t-commentId');
    const t_user = localStorage.getItem('t-userId');
    const sub_comment = document.getElementById('comment-' + t_commentId).value;
    if (sub_comment.length > 0) {
        const data = await authRequest('http://localhost:3020/api/subcomments',
            "POST",
            JSON.stringify({
                commentId: t_commentId,
                talkTo: t_user,
                sub_comment: sub_comment,
            }));
        if (data.code == 1) {
            document.getElementById(t_commentId).style.display = 'none';
            alert('comment successful');
            window.location.href = window.location.href;
        }
    } else {
        alert('please input sub comment');
    }
}


const reply_sub = async (r) => {
    const cid_un = r.id.split('-');
    const usedBlock = localStorage.getItem('t-used');

    if (usedBlock) {
        document.getElementById(usedBlock).style.display = 'none';
    }
    localStorage.setItem('t-p-commentiD', cid_un[0]);
    localStorage.setItem('t-sub-commentId', cid_un[1]);
    localStorage.setItem('t-sub-userId', cid_un[2]);

    localStorage.setItem('t-used', cid_un[1]);


    document.getElementById(cid_un[1]).style.display = 'block';
    // const data = authRequest('http://');
}

const save_sub__comment = async() => {
    const t_p_commentiD = localStorage.getItem('t-p-commentiD');
    const t_sub_commentId = localStorage.getItem('t-sub-commentId');
    const t_sub_username = localStorage.getItem('t-sub-userId');
    const sub_comment = document.getElementById('comment-' + t_sub_commentId).value;
    if (sub_comment.length > 0) {
        const data = await authRequest('http://localhost:3020/api/subcomments',
            "POST",
            JSON.stringify({
                commentId: t_p_commentiD,
                talkTo: t_sub_username,
                sub_comment: sub_comment,
            }));
        if (data.code == 1) {
            document.getElementById(t_sub_commentId).style.display = 'none';
            alert('comment successful');
            window.location.href = window.location.href;
        }
    } else {
        alert('please input your comment');
    }
}

const delete_comment = async (r) => {
    const idArr = r.id.split('-');
    const type = idArr[0];
    const commentId = idArr[2];
    if (type == 0) {
        const res = await authRequest('http://localhost:3020/api/comments/delete', 'POST', JSON.stringify({
            commentId: commentId
        }));
        if (res.code == 1) {
            alert(res.msg);
        }

    } else {
        const res = await authRequest('http://localhost:3020/api/subcomments/delete', 'POST', JSON.stringify({
            subCommentId: commentId
        }));
        if (res.code == 1) {
            alert(res.msg);
        }
    }

    window.location.href = window.location.href;

}

(async() => {
    const darr = dcommentStr.split(';');
    for (const e of darr) {

        document.getElementById(e).style.display = 'none';


        if (userId == authorId) {
            document.getElementById(e).style.display = 'block';
        } else {
            const earr = e.split('-');
            const createUserId = earr[1];

            if (createUserId == userId) {
                document.getElementById(e).style.display = 'block';
            }

        }
    }
})();




// const articleId = window.location.href.split('/').slice(-1);
//
// const save_comment = async () => {
//     const comment = document.getElementById('comment').value;
//     if (comment.length == 0) {
//         alert("please input comment");
//     } else{
//         const data = await authRequest('http://localhost:3020/api/comments',
//             "POST",
//             JSON.stringify({
//                 ArticleID: articleId,
//                 Comment: comment
//             }));
//         if (data.code == 1) {
//             alert("create comment successful");
//             window.location.href = window.location.href;
//         }
//
//     }
// }
//
//
// const reply = async (r) => {
//     const cid_un = r.id.split('-');
//     const commentId = cid_un[0];
//     const usedBlock = localStorage.getItem('t-used');
//
//     console.log("=-----------------------");
//     if (usedBlock) {
//         const e = document.getElementById(usedBlock);
//         if (e) {
//             e.style.display = 'none';
//         }
//     }
//
//     localStorage.setItem('t-commentId', cid_un[0]);
//     localStorage.setItem('t-username', cid_un[1]);
//     localStorage.setItem('t-used', commentId);
//
//     document.getElementById(commentId).style.display = 'block';
//     // const data = authRequest('http://');
// }
//
// const save_sub_comment = async() => {
//     const t_commentId = localStorage.getItem('t-commentId');
//     const t_user = localStorage.getItem('t-username');
//     const sub_comment = document.getElementById('comment-' + t_commentId).value;
//     if (sub_comment.length > 0) {
//         const data = await authRequest('http://localhost:3020/api/subcomments',
//             "POST",
//             JSON.stringify({
//                 commentId: t_commentId,
//                 talkTo: t_user,
//                 sub_comment: sub_comment,
//             }));
//         if (data.code == 1) {
//             document.getElementById(t_commentId).style.display = 'none';
//             alert('comment successful');
//             window.location.href = window.location.href;
//         }
//     } else {
//         alert('please input sub comment');
//     }
// }
//
//
// const reply_sub = async (r) => {
//     const cid_un = r.id.split('-');
//     const subCommentId = cid_un[0];
//     const usedBlock = localStorage.getItem('t-used');
//
//     if (usedBlock) {
//         document.getElementById(usedBlock).style.display = 'none';
//     }
//     localStorage.setItem('t-p-commentiD', cid_un[0]);
//     localStorage.setItem('t-sub-commentId', cid_un[1]);
//     localStorage.setItem('t-sub-username', cid_un[2]);
//
//     localStorage.setItem('t-used', cid_un[1]);
//
//
//     document.getElementById(cid_un[1]).style.display = 'block';
//     // const data = authRequest('http://');
// }
//
// const save_sub__comment = async() => {
//     const t_p_commentiD = localStorage.getItem('t-p-commentiD');
//     const t_sub_commentId = localStorage.getItem('t-sub-commentId');
//     const t_sub_username = localStorage.getItem('t-sub-username');
//     const sub_comment = document.getElementById('comment-' + t_sub_commentId).value;
//     if (sub_comment.length > 0) {
//         const data = await authRequest('http://localhost:3020/api/subcomments',
//             "POST",
//             JSON.stringify({
//                 commentId: t_p_commentiD,
//                 talkTo: t_sub_username,
//                 sub_comment: sub_comment,
//             }));
//         if (data.code == 1) {
//             document.getElementById(t_sub_commentId).style.display = 'none';
//             alert('comment successful');
//             window.location.href = window.location.href;
//         }
//     } else {
//         alert('please input your comment');
//     }
// }