const token = localStorage.getItem('token');
const username = localStorage.getItem('username');
const avatar = localStorage.getItem('avatar');
const userId = localStorage.getItem('userId');


const img = document.querySelector('.header-box .nav li img');
const userInfo = document.querySelector('.header-box .nav li p');
const manageArticle = document.getElementById('managelink');

const starlink = document.getElementById('starlink');

const home = document.getElementById('home');

const home = document.getElementById('home');

if (token) {
    console.log(token)
    if (avatar) {
        img.src = `http://localhost:3020/images/avatar/${avatar}`;
    }

    if (nickname) {
        userInfo.innerHTML= `${nickname}`;
        manageArticle.href = `http://localhost:3020/${userId}/managearticle`;
        starlink.href = `http://localhost:3020/${userId}/stararticles`;
        home.href = `http://localhost:3020/${userId}/index`;
    }


} else {
    document.getElementById('manage').style.display="none";
    document.getElementById('star').style.display = "none";
    document.getElementById('create').style.display = "none";
    document.getElementById('logout').style.display = "none";
    img.src = `http://localhost:3020/images/login.png`;

}

const login_or_update = () => {
    if (token) {
        window.location.href = `http://localhost:3020/userinfo/${userId}`;
    } else {
        window.location.href = 'http://localhost:3020/login'
    }
}


const logout = () => {
    localStorage.removeItem('nickname');
    localStorage.removeItem('avatar');
    localStorage.removeItem('userId');
    localStorage.removeItem('token');
    window.location.href = 'http://localhost:3020/';
}