const request = async (url, method, body) => {
    const response = await fetch(url, {
        method: method,
        headers: {
            "Content-Type": "application/json"
        },
        body: body
    });
    const data = await response.json();
    return data;
}


const authRequest = async (url, method, body) => {
    const token = localStorage.getItem('token');
    const response = await fetch(url, {
        method: method,
        headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token
        },
        body: body
    });
    const data = await response.json();
    return data;

}