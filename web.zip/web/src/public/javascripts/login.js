if (localStorage.getItem('token')) {
    window.location.href = 'http://localhost:3020/index'
}

const login = (port) => {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    if (username.length == 0) {
        alert("please input your user name");
    } else if (password.length == 0) {
        alert("please input your password");
    }
    if (username.length > 0 && password.length > 0) {
        fetch(`http://localhost:${port}/api/users/login`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ "username": username, "password": password })
        }).then((response) => response.json())
            .then((data) => {
                if (data.code == 1) {
                    localStorage.setItem('token', data.token);
                    localStorage.setItem('username', data.username);
                    localStorage.setItem('avatar', data.avatar);
                    window.location.href = `http://localhost:${port}/index`;
                } else {
                    alert(data.msg);
                }
            }).catch(err => {
            console.error(err);
        });
    }

}