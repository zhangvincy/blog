const hide_show = (r) => {
  if (r.innerHTML == 'Hide Comments') {
    document.getElementById('comments-box').style.display = 'none';
    r.innerHTML = 'show omments'
  } else {
    document.getElementById('comments-box').style.display = 'flex';
    r.innerHTML = 'Hide Comments'
  }
 
}


window.addEventListener("beforeprint", (event) => {
  console.log("Before print");
});

window.onbeforeprint = (event) => {
  console.log("Before print");
};