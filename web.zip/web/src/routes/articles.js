var express = require('express');
var router = express.Router();

var articlesModel = require('../models/articlesModel');
const commentsModel = require('../models/commentsModel');
const subCommentsModel = require('../models/subcommentsModel');
const starsModel = require('../models/starsModel');
/**
 * post /api/articles
 * publish article
 */
router.post('/', function(req, res, next) {
    // console.log(req.body);
    console.log(req.auth);
    if (req.auth.username == req.body.username) {
        articlesModel.createArticle(req.body.title, req.body.content, req.body.username);
        res.json({
            code: 1,
            msg: "publish article successful"
        });
    } else {
        res.json({
            code: 0,
            msg: 'invalid author'
        })
    }
});


router.get('/', (req, res, next) => {
    articlesModel.queryAll().then(data => {

    })
});

/**
 * get /api/articles/users/:uname
 * get article by user name
 */
router.get('/users/:uname', function(req, res, next) {
    console.log(req.params)
    res.json({
        code: 1,
        msg: "get article with user name"
    });
});


/**
 * get /api/articles/:aid
 * get article by article id
 */
router.get('/:aid', async function(req, res, next) {
    const data = await articlesModel.queryById(req.params.aid);
    console.log("++",data)
    res.json({
        code: 1,
        data: data
    });
});

/**
 * delete /api/articles/:aid
 * delete article by article id
 */
router.delete('/:aid', async function(req, res, next) {
    const comments = await commentsModel.queryByArticleId(req.params.aid);
    await starsModel.deleteAllWithArticlesId(req.params.aid);
    if (JSON.stringify(comments) == '{}') {
        await articlesModel.deleteArticle(req.params.aid);
    } else {
        for (comment of comments.comments) {
            console.log(comment)
            await subCommentsModel.deleteAllWithPCommentID(comment.CommentID);
            await commentsModel.deleteComment(comment.CommentID);
        }
        await articlesModel.deleteArticle(req.params.aid);
    }

    res.json({
        code: 1,
        msg: "delete successful"
    });
});


/**
 * post /api/articles/:aid
 * update article by article id
 */
router.post('/:aid', function(req, res, next) {
    console.log('title', req.body.title);
    articlesModel.updateArticle(req.params.aid, req.body.content, req.body.title);
    res.json({
        code: 1,
        msg: "update successful"
    });
});

module.exports = router;
