var express = require('express');
var router = express.Router();

var starsModel = require('../models/starsModel');

router.post("/", (req, res) => {
    const username = req.auth.username;
    const articleId = req.body.articleId;
    starsModel.createStar(username, articleId);
    res.json({
        code: 1,
        msg: "star successful"
    })
});

router.post("/query", async (req, res) => {
    const username = req.auth.username;
    const articleId = req.body.articleId;
    const query = await starsModel.queryStar(username, articleId);
    console.log(query);
    if (JSON.stringify(query) === '{}') {
        res.json({
            code: 0,
            msg: "star not exits"
        });
    } else {
        res.json({
            code: 1,
            msg: "star exits"
        });
    }
});

router.post("/cancel", (req, res) => {
    const username = req.auth.username;
    const articleId = req.body.articleId;
    starsModel.deleteStar(username, articleId);
    res.json({
        code: 1,
        msg: "delete star successful"
    })
});

module.exports = router;
