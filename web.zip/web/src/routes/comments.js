var express = require('express');
var router = express.Router();

const commentsModel = require('../models/commentsModel');
const subCommentsModel = require('../models/subcommentsModel');


router.post('/', async (req, res) => {
    // console.log(req.body);
    console.log(req.auth);
    const userId = req.auth.userId;
    const articleId = req.body.ArticleID;
    const comment = req.body.Comment;
    await commentsModel.createComment(userId, articleId, comment);
    res.json({
        code: 1,
        msg: "create comment successful"
    })
});

router.post('/delete', async (req, res) => {
    const commentId = req.body.commentId;
    await subCommentsModel.deleteAllWithPCommentID(commentId);
    await commentsModel.deleteComment(commentId);
    res.json({
        code: 1,
        msg: 'delete successful'
    })
})

module.exports = router;




// var express = require('express');
// var router = express.Router();
//
// const commentsModel = require('../models/commentsModel');
//
// router.post('/', function(req, res, next) {
//     // console.log(req.body);
//     console.log(req.auth);
//     const username = req.auth.username;
//     const articleId = req.body.ArticleID;
//     const comment = req.body.Comment;
//     commentsModel.createComment(username, articleId, comment);
//     res.json({
//         code: 1,
//         msg: "create comment successful"
//     })
// });
//
//
// module.exports = router;
