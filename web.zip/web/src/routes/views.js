var express = require('express');
var router = express.Router();

const fs = require('fs');
const path = require('path');

const EncryptRsa = require('encrypt-rsa').default;
const encryptRsa = new EncryptRsa();

const usersModel = require('../models/userModel');
const articlesModel = require('../models/articlesModel');
const starsModel = require('../models/starsModel');
const commentsModel = require('../models/commentsModel');
const subCommentsModel = require('../models/subcommentsModel');

const utils = require('../utils/date');

router.get("/index", async (req, res) => {
    const articles = await articlesModel.queryAll();
    articles.articles.forEach(async e => {
        e['CreateUser'] = await usersModel.queryNickNameByUserId(e.CreateUserID);
    });
    articles.articles.sort((a, b) => {
        return a.InsertTime < b.InsertTime ? 1 : -1;
    });

    for (article in articles.articles) {
        const date = articles.articles[article].InsertTime
        articles.articles[article].InsertTime = utils.getTime(date)

        const articleId = articles.articles[article].ArticleID;
        const stars = await starsModel.queryStarByArticleId(articleId);
        articles.articles[article].Star = stars.stars.length;
    }
    res.render('index', articles);
})

router.get("/:userId/index", async (req, res) => {
    const articles = await articlesModel.queryAll();

    articles.articles.forEach(async e => {
        e['CreateUser'] = await usersModel.queryNickNameByUserId(e.CreateUserID);
    });

    articles.articles.sort((a, b) => {
        return a.InsertTime < b.InsertTime ? 1 : -1;
    });

    for (article in articles.articles) {
        const date = articles.articles[article].InsertTime
        articles.articles[article].InsertTime = utils.getTime(date)

        const articleId = articles.articles[article].ArticleID;
        const stars = await starsModel.queryStarByArticleId(articleId);
        articles.articles[article].Star = stars.stars.length;

        const star = await starsModel.queryStar(req.params.userId, articleId);
        articles.articles[article]["isStar"] = JSON.stringify(star) === '{}' ? false : true;
    }

    res.render('index', articles);
});

router.get('/:userId/stararticles', async (req, res) => {
    const stars = await starsModel.queryByUserName(req.params.userId);
    const articles = { articles: [] };

    if (stars.stars.length > 0) {
        for (star of stars.stars) {
            const articleId = star.ArticleID;
            const article = await articlesModel.queryById(articleId);

            article.InsertTime = utils.getTime(article.InsertTime)
            const lstar = await starsModel.queryStarByArticleId(articleId);
            article['Star'] = lstar.stars.length;
            article["isStar"] = true;

            articles.articles.push(article);
        }

    }
    articles.articles.forEach(async e => {
        e['CreateUser'] = await usersModel.queryNickNameByUserId(e.CreateUserID);
    });
    console.log(articles);
    res.render('starsArticle', articles);
});


router.get('/:userId/managearticle', async (req, res) => {
    const articles = await articlesModel.queryByUserName(req.params.userId);
    if (JSON.stringify(articles) !== '{}') {
        articles.articles.forEach(async e => {
            e['CreateUser'] = await usersModel.queryNickNameByUserId(e.CreateUserID);
        });
    }
    if (JSON.stringify(articles) != '{}') {
        articles.articles.sort((a, b) => {
            return a.InsertTime < b.InsertTime ? 1 : -1;
        })

    }
    for (article in articles.articles) {
        const date = articles.articles[article].InsertTime;
        articles.articles[article].InsertTime = utils.getTime(date);

        const articleId = articles.articles[article].ArticleID;
        const stars = await starsModel.queryStarByArticleId(articleId);
        articles.articles[article].Star = stars.stars.length;

        const star = await starsModel.queryStar(req.params.userId, articleId);
        articles.articles[article]["isStar"] = JSON.stringify(star) === '{}' ? false : true;
    }
    res.render('manageArticle', articles);
})


router.get("/login", (req, res)=> {
    res.render('login', { port: process.env.EXPRESS_PORT  });
})

router.get("/bloginfo/:id", async (req, res)=> {
    const query = await articlesModel.queryById(req.params.id);

    query['comments'] = {}
    query['dcomments'] = ""
    const comments = await commentsModel.queryByArticleId(req.params.id);
    if (JSON.stringify(comments) != '{}') {
        comments.comments.sort( (a, b) => {
            return a.InsertTime < b.InsertTime ? 1 : -1;
        })
        comments.comments.map(e=> {
            e.InsertTime = utils.getTime(e.InsertTime);
            if (query['dcomments'].length == 0) {
                query['dcomments'] = `0-${e.CreateUserID}-${e.CommentID}`;
            } else {
                query['dcomments'] += `;0-${e.CreateUserID}-${e.CommentID}`;
            }
        })
        for (comment of comments.comments) {
            comment['Avatar'] = await usersModel.queryAvatar(comment.CreateUserID);
            comment['UserNickName'] = await usersModel.queryNickNameByUserId(comment.CreateUserID);
            const sub_comments = await subCommentsModel.queryByCommentId(comment.CommentID);
            if (sub_comments.sub_comments.length > 0) {
                sub_comments.sub_comments.sort((a, b) => {
                    return a.InsertTime < b.InsertTime ? 1 : -1;
                })
                comment['SubComments'] = sub_comments.sub_comments;
                for (sub_com of comment['SubComments']) {
                    sub_com['UserNickName'] = await usersModel.queryNickNameByUserId(sub_com.CreateUserID);
                    sub_com['TUserNickName'] = await usersModel.queryNickNameByUserId(sub_com.TalkTo);
                    sub_com['Avatar'] = await usersModel.queryAvatar(sub_com.CreateUserID);
                    sub_com['TAvatar'] = await usersModel.queryAvatar(sub_com.TalkTo);
                    sub_com['InsertTime'] = utils.getTime(sub_com.InsertTime);

                    query['dcomments'] += `;1-${sub_com.CreateUserID}-${sub_com.SubCommentID}`;

                }
            } else {
                comment['SubComments'] = [];
            }
        }
        query['comments'] = comments.comments;

    }
    query['Author'] = await usersModel.queryNickNameByUserId(query.CreateUserID);
    // console.log("========",query.comments[0].SubComments);
    // console.log(query.dcomments);
    res.render('bloginfo', query);

})

router.get("/createarticle", (req, res) => {
    res.render('createArticle');
})

router.get('/edit/:id', async (req, res) => {
    const commentId = req.params.id;
    const content = await articlesModel.queryById(commentId);
    console.log(content);
    res.render('edit', content);
})

router.get('/register', (req, res)=>  {
    let config = {};
    const directoryPath = path.join(__dirname, '..', 'public', 'images', 'avatar');
    config['avatar'] = fs.readdirSync(directoryPath);
    config['port'] = process.env.EXPRESS_PORT;

    res.render('register', config);
});

router.get("/", (req, res) => {
    res.redirect(`http://localhost:${process.env.EXPRESS_PORT}/index`);
})

router.get("/userinfo/:uid", async (req, res) => {
    const user = await usersModel.queryByUserId(req.params.uid);
    user.UserBirthDay = utils.getTime(user.UserBirthDay).split(' ')[0];
    user.UserPassword = encryptRsa.decryptStringWithRsaPrivateKey({
        text: user.UserPassword,
        privateKey: process.env.PRIVATE_KEY,
    });
    console.log(user)
    res.render('userinfo', user);
})

module.exports = router;



// var express = require('express');
// var router = express.Router();
//
// const fs = require('fs');
// const path = require('path');
//
// const usersModel = require('../models/userModel');
// const articlesModel = require('../models/articlesModel');
// const starsModel = require('../models/starsModel');
// const commentsModel = require('../models/commentsModel');
// const subCommentsModel = require('../models/subcommentsModel');
//
// const utils = require('../utils/date');
//
// router.get("/index", async (req, res) => {
//     const articles = await articlesModel.queryAll();
//     articles.articles.sort((a, b) => {
//         return a.InsertTime < b.InsertTime ? 1 : -1;
//     });
//
//     for (article in articles.articles) {
//         const date = articles.articles[article].InsertTime
//         articles.articles[article].InsertTime = utils.getTime(date)
//
//         const articleId = articles.articles[article].ArticleID;
//         const stars = await starsModel.queryStarByArticleId(articleId);
//         articles.articles[article].Star = stars.stars.length;
//     }
//     res.render('index', articles);
// })
//
// router.get("/:username/index", async (req, res) => {
//     const articles = await articlesModel.queryAll();
//     articles.articles.sort((a, b) => {
//         return a.InsertTime < b.InsertTime ? 1 : -1;
//     });
//
//     for (article in articles.articles) {
//         const date = articles.articles[article].InsertTime
//         articles.articles[article].InsertTime = utils.getTime(date)
//
//         const articleId = articles.articles[article].ArticleID;
//         const stars = await starsModel.queryStarByArticleId(articleId);
//         articles.articles[article].Star = stars.stars.length;
//
//         const star = await starsModel.queryStar(req.params.username, articleId);
//         articles.articles[article]["isStar"] = JSON.stringify(star) === '{}' ? false : true;
//     }
//
//     res.render('index', articles);
// });
//
// router.get('/:username/stararticles', async (req, res) => {
//     const stars = await starsModel.queryByUserName(req.params.username);
//     const articles = { articles: [] };
//     console.log(stars.stars);
//     if (stars.stars.length > 0) {
//         for (star of stars.stars) {
//             const articleId = star.ArticleID;
//             const article = await articlesModel.queryById(articleId);
//
//             article.InsertTime = utils.getTime(article.InsertTime)
//             const lstar = await starsModel.queryStarByArticleId(articleId);
//             article['Star'] = lstar.stars.length;
//             article["isStar"] = true;
//
//             articles.articles.push(article);
//         }
//         res.render('starsArticle', articles);
//     } else {
//         res.render('starsArticle', articles);
//     }
// });
//
//
// router.get('/:username/managearticle', async (req, res) => {
//     const articles = await articlesModel.queryByUserName(req.params.username);
//     if (JSON.stringify(articles) != '{}') {
//         articles.articles.sort((a, b) => {
//             return a.InsertTime < b.InsertTime ? 1 : -1;
//         })
//
//     }
//     for (article in articles.articles) {
//         const date = articles.articles[article].InsertTime;
//         articles.articles[article].InsertTime = utils.getTime(date);
//
//         const articleId = articles.articles[article].ArticleID;
//         const stars = await starsModel.queryStarByArticleId(articleId);
//         articles.articles[article].Star = stars.stars.length;
//
//         const star = await starsModel.queryStar(req.params.username, articleId);
//         articles.articles[article]["isStar"] = JSON.stringify(star) === '{}' ? false : true;
//     }
//     res.render('manageArticle', articles);
// })
//
//
// router.get("/login", (req, res)=> {
//     res.render('login', { port: process.env.EXPRESS_PORT  });
// })
//
// router.get("/bloginfo/:id", async (req, res)=> {
//     const query = await articlesModel.queryById(req.params.id);
//     query['comments'] = {}
//     const comments = await commentsModel.queryByArticleId(req.params.id);
//     if (JSON.stringify(comments) != '{}') {
//         comments.comments.sort( (a, b) => {
//             return a.InsertTime < b.InsertTime ? 1 : -1;
//         })
//         comments.comments.map(e=> {
//             e.InsertTime = utils.getTime(e.InsertTime);
//         })
//         for (comment of comments.comments) {
//             comment['Avatar'] = await usersModel.queryAvatar(comment.UserName);
//             const sub_comments = await subCommentsModel.queryByCommentId(comment.CommentID);
//             if (sub_comments.sub_comments.length > 0) {
//                 sub_comments.sub_comments.sort((a, b) => {
//                     return a.InsertTime < b.InsertTime ? 1 : -1;
//                 })
//                 comment['SubComments'] = sub_comments.sub_comments;
//                 for (sub_com of comment['SubComments']) {
//                     sub_com['Avatar'] = await usersModel.queryAvatar(sub_com.UserName);
//                     sub_com['TAvatar'] = await usersModel.queryAvatar(sub_com.TalkTo);
//                     sub_com['InsertTime'] = utils.getTime(sub_com.InsertTime);
//                 }
//             } else {
//                 comment['SubComments'] = [];
//             }
//         }
//         query['comments'] = comments.comments;
//
//     }
//     console.log(query);
//     // console.log(query.comments[0].SubComments);
//     res.render('bloginfo', query);
//
// })
//
// router.get("/createarticle", (req, res) => {
//     res.render('createArticle');
// })
//
// router.get('/edit/:id', async (req, res) => {
//     const commentId = req.params.id;
//     const content = await articlesModel.queryById(commentId);
//     console.log(content);
//     res.render('edit', content);
// })
//
// router.get('/register', (req, res)=>  {
//     let config = {};
//     const directoryPath = path.join(__dirname, '..', 'public', 'images', 'avatar');
//     config['avatar'] = fs.readdirSync(directoryPath);
//     config['port'] = process.env.EXPRESS_PORT;
//
//     res.render('register', config);
// });
//
// router.get("/", (req, res) => {
//     res.redirect(`http://localhost:${process.env.EXPRESS_PORT}/index`);
// })
//
// module.exports = router;
