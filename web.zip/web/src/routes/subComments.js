var express = require('express');
var router = express.Router();

const subCommentsModel = require('../models/subcommentsModel');

router.post('/', async (req, res) => {
    const userId = req.auth.userId;
    await subCommentsModel.createSubComment(req.body.commentId, userId, req.body.talkTo, req.body.sub_comment);
    res.json({
        code: 1,
        msg: 'sub comment successful'
    })
})

router.post('/delete', async (req, res) => {
    const subCommentId = req.body.subCommentId;
    await subCommentsModel.deleteSubComment(subCommentId);
    res.json({
        code: 1,
        msg: 'delete successful'
    })
})

module.exports = router;


// var express = require('express');
// var router = express.Router();
//
// const subCommentsModel = require('../models/subcommentsModel');
//
// router.post('/', (req, res) => {
//     const username = req.auth.username;
//     await subCommentsModel.createSubComment(req.body.commentId, userId, req.body.talkTo, req.body.sub_comment);
//     // subCommentsModel.createSubComment(req.body.commentId, username, req.body.talkTo, req.body.sub_comment);
//     res.json({
//         code: 1,
//         msg: 'sub comment successful'
//     })
// })
//
// router.post('/delete', async (req, res) => {
//     const subCommentId = req.body.subCommentId;
//     await subCommentsModel.deleteSubComment(subCommentId);
//     res.json({
//         code: 1,
//         msg: 'delete successful'
//     })
// })
//
// module.exports = router;
