var express = require('express');
var router = express.Router();

var multer = require('multer');
var path = require('path');
var storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, "src/public/images/uploads");
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
})

var upload = multer({storage: storage}).single('file');


router.post('/', upload, (req, res) => {
    const file = req.file.path;
    const url = file.split('/').slice(2,10).join('/');
    const alt = req.file.originalname.split('.')[0];
    console.log(req.file,   url);

    res.json({
        errno: 0,
        data: {
            url: `http://localhost:${process.env.EXPRESS_PORT}/` + url,
            alt
        }

    })
});

module.exports = router;
