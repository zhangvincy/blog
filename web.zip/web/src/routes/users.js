var express = require('express');
let jwt = require("jsonwebtoken");

const userModel = require('../models/userModel');
const user = require('../models/user');
const EncryptRsa = require('encrypt-rsa').default;

const encryptRsa = new EncryptRsa();

var router = express.Router();


router.post('/checknickname', async (req, res, next) => {
    const db_res = await userModel.checkNickName(req.body.nickname);
    res.json(db_res);
});

/* Post user register */
router.post('/', async (req, res, next) => {
    const encryptedPassword = encryptRsa.encryptStringWithRsaPublicKey({
        text: req.body.password,
        publicKey: process.env.PUBLIC_KEY,
    });
    const newUser = new user.User(req.body.nickname, encryptedPassword, req.body.realname,
        req.body.birthday, req.body.avatar, req.body.description);
    const db_res = await userModel.createUser(newUser);
    res.json(db_res);
});


/* GET user login */
router.post('/login', function (req, res, next) {
    userModel.checkUser(req.body.nickname, req.body.password).then(data => {
        if (data.code == 1 && data.correct == 1) {
            let token = jwt.sign({ "nickname": data.nickname, "userId": data.userId }, "signature", {
                expiresIn: '365d',
                algorithm: "HS256"
            });
            res.json({
                code: 1,
                msg: "login successful",
                userId: data.userId,
                nickname: data.nickname,
                avatar: data.avatar,
                token
            });
        } else {
            res.json({
                code: 0,
                msg: 'username or password not correct'
            })
        }
    })

});

router.post('/update', async (req, res) => {
    const userId = req.auth.userId;
    const encryptedPassword = encryptRsa.encryptStringWithRsaPublicKey({
        text: req.body.password,
        publicKey: process.env.PUBLIC_KEY,
    });
    await userModel.update(req.body.nickname, encryptedPassword, req.body.realName,
        req.body.description, req.body.birthday, userId);

    let token = jwt.sign({ "nickname": req.body.nickname, "userId": userId }, "signature", {
        expiresIn: '365d',
        algorithm: "HS256"
    });

    res.json({
        code: 1,
        msg: 'update successful',
        nickname: req.body.nickname,
        token
    })
} );

router.post('/delete', async (req, res) => {
    const userId = req.auth.userId;
    await userModel.deleteUser(userId);
    res.json({
        code: 1,
        msg: 'delete account successful'
    })

});

module.exports = router;

// var express = require('express');
// let jwt = require("jsonwebtoken");
//
//
// const userModel = require('../models/userModel');
// var router = express.Router();
//
// router.post('/checkuser', function (req, res, next) {
//     userModel.checkUser(req.body.username, req.body.password).then(data => {
//         res.json(data);
//     })
// });
//
// /* Post user register */
// router.post('/', function (req, res, next) {
//     userModel.createUser(req.body.username, req.body.password, req.body.avatar).then( data => {
//         res.json(data);
//     });
// });
//
//
// /* GET user login */
// router.post('/login', function (req, res, next) {
//     userModel.checkUser(req.body.username, req.body.password).then(data => {
//         if (data.code == 1 && data.correct == 1) {
//             let token = jwt.sign({ "username": data.username }, "signature", {
//                 expiresIn: '365d',
//                 algorithm: "HS256"
//             });
//             res.json({
//                 code: 1,
//                 msg: "login successful",
//                 username: data.username,
//                 avatar: data.avatar,
//                 token
//             });
//         } else {
//             res.json({
//                 code: 0,
//                 msg: 'username or password not correct'
//             })
//         }
//     })
//
// });
//
// module.exports = router;
