// Load a .env file if one exists
require('dotenv').config()

const express = require("express");
const handlebars = require("express-handlebars");
const path = require('path');

const app = express();

// Listen port will be loaded from .env file, or use 3000 if
const port = process.env.EXPRESS_PORT || 3000;

// Setup Handlebars
app.engine("handlebars", handlebars.create({
    defaultLayout: null,
    partialsDir: path.join(__dirname, "src", "views", "partials")
}).engine);
app.set("view engine", "handlebars");

// Set up to read POSTed form data
app.use(express.urlencoded({ extended: true }));
app.use(express.json({}));


// TODO: Your app here
var { expressjwt } = require("express-jwt");

app.use(express.static(path.join(__dirname, 'src', 'public')));
app.set('views', path.join(__dirname, 'src', 'views'));


var articlesRouter = require('./src/routes/articles');
var usersRouter = require('./src/routes/users');
var viewsRouter = require('./src/routes/views');
var fileUploads = require('./src/routes/fileUploads');
var starsRouter = require('./src/routes/stars');
var commentsRouter = require('./src/routes/comments');
var subCommentsRouter = require('./src/routes/subComments');

app.use((req, res, next) => {
    console.log(`${req.method} ${req.url}`)
    next()
})


app.use(expressjwt({
    secret: 'signature',
    algorithms: ['HS256'],
}).unless({
    path: [
        /^\/$/,
        /^\/bloginfo\/\d+/,
        "/index",
        "/login",
        "/register",
        "/createarticle",
        "/api/fileuploads",
        /^\/\d+\/stararticles/,
        /^\/images\/avatar\/\w+/,
        "/api/users/",
        "/api/users/checknickname",
        "/api/users/login",
        /\w+\/managearticle$/,
        /\w+\/index$/,
        "/favicon.ico",
        /^\/userinfo\/\d+/,
        /^\/javascripts\/\w+/,
        /^\/edit\/\w+/,
        {
            url: /^\/api\/articles\/\w+/,
            methods: ['GET']
        }
    ]
}));

app.use('/', viewsRouter);
app.use('/api/articles', articlesRouter);
app.use('/api/users', usersRouter);
app.use('/api/fileuploads', fileUploads);
app.use('/api/stars', starsRouter);
app.use('/api/comments', commentsRouter);
app.use('/api/subcomments', subCommentsRouter);


app.listen(port, function () {
    console.log(`Web final project listening on http://localhost:${port}/`);
});
